create procedure proc_obtenerODA(IN objetoAprendizaje varchar(500))
select nombre_objetoaprendizaje, descripcion_objetoaprendizaje,nombre_unidadaprendizaje, nombre_tipoobjeto, nombre_licenciatura, enlace_objetoaprendizaje
	from objetoaprendizaje inner join tipoobjeto on objetoaprendizaje.id_tipoobjeto = tipoobjeto.id_tipoobjeto
	inner join licenciatura_unidadaprendizaje on objetoaprendizaje.id_licenciatura = licenciatura_unidadaprendizaje.id_licenciatura
	inner join subcategoria on objetoaprendizaje.id_subcategoria = subcategoria.id_subcategoria
	inner join autor on objetoaprendizaje.id_autor = autor.id_autor
	where nombre_objetoaprendizaje like concat('%',objetoAprendizaje,'%');

