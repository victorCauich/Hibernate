create procedure proc_obtenercarreras()
select distinct nombre_licenciatura from licenciatura_unidadaprendizaje order by nombre_licenciatura asc;

