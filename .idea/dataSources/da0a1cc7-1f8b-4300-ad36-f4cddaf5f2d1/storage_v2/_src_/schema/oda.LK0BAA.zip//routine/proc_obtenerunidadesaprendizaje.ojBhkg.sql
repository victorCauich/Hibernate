create procedure proc_obtenerunidadesaprendizaje(IN unidadaprendizaje varchar(100))
select nombre_unidadaprendizaje from licenciatura_unidadaprendizaje
    where nombre_licenciatura = unidadaprendizaje order by nombre_unidadaprendizaje;

